<?php

/**
* @package 		VALogs
* @subpackage 	FronteEnd
* @contact 		jitendra.kumar@dotsquares.com
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
* View of Attach Action
* @author Jitendra Khatri
*/
require_once dirname(__FILE__).'/view.php';

class TimelineAdminViewItems extends TimelineAdminBaseViewItems
{
}