<?php
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();


class TimelineTable extends Rb_Table
{
	public $_component = TIMELINE_COMPONENT_NAME;
}
