<?php 
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();

class TimelineController extends Rb_Controller
{
	public $_component = TIMELINE_COMPONENT_NAME;
}
