<?php
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();


class TimelineRoute extends Rb_Route
{
	public $_component = TIMELINE_COMPONENT_NAME;
}
