<?php
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();

class TimelineHtml extends Rb_Html
{
	public $_component = TIMELINE_COMPONENT_NAME;
}