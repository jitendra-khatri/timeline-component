<?php 
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();

abstract class TimelinePlugin extends Rb_Plugin
{
	public $_component	= TIMELINE_COMPONENT_NAME;
}
