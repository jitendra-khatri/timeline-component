<?php
/**
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

class TimelineHelperLoader extends Rb_HelperLoader
{
}