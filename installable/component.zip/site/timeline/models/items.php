<?php 
/**
* @subpackage	Frontend
* @contact 		jitendra.kumar@dotsquares.com
* @author		Jitendra Khatri
*/
if(defined('_JEXEC')===false) die();


class TimelineModelItems extends TimelineModel
{

}

class TimelineModelformItems extends TimelineModelform 
{
	
}
